
import java.util.Scanner;

import java.time.LocalDateTime;
import java.util.Random;

import java.util.ArrayList;
import java.util.List;

import java.io.File;
import java.io.FileNotFoundException;


public class palavraSorteada {

    String filePath = "br-utf8.txt"; //"src/AP3/br-utf8.txt"

    List <String> list = new ArrayList<String>();
    private String aPalavra;
    
    
    public palavraSorteada() {
        deArquivoParaList();
        aPalavra = geradorDaPalavra();
    }
    
    public String getaPalavra() {
        return aPalavra;
    }
    
    private void deArquivoParaList() {

        try {

            File file = new File(filePath);
            Scanner sc = new Scanner(file);

            while(sc.hasNextLine()) {
                String line = sc.nextLine();
                list.add(line);
            }

            sc.close();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }

    private String geradorDaPalavra() {

        // Obter a hora atual
        LocalDateTime now = LocalDateTime.now();
    
        // Obter os componentes de hora, minuto, segundo e nanossegundo
        int hour = now.getHour();
        int minute = now.getMinute();
        int second = now.getSecond();
        int nanosecond = now.getNano();
    
        // Concatenar os componentes para formar uma semente
        long seed = hour * 1000000000L + minute * 10000000L + second * 100000L + nanosecond;
    
        // Criar uma instância do gerador de números aleatórios com a semente
        Random random = new Random(seed);

        return list.get(random.nextInt(5906));
    }


}
