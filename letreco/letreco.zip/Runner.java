

import java.util.Scanner;

public class Runner {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("Digite 5 para jogar: ");
        System.out.print("-> ");

        Integer iniciar = sc.nextInt();

        while (iniciar == 5) {
            sc.nextLine();
            processamentoDoPalpite myGuess = new processamentoDoPalpite();
            System.out.println("\nVamos começar!\n");
           
            for(int i=1; i <= 6;i++) {


                System.out.print("Digite palpite #"+ i +": ");
                String tentativa = sc.nextLine();

                myGuess.setPalavraTentada(tentativa);

                System.out.println("Palpite:\t" + myGuess.impressaoPalpite());

                System.out.println("Resultado:\t" + myGuess.impressaoResposta());


           }
           /*Digite palpite #1: torta
            Palpite:    t o r t a
            Resultado: - * * * *            */
           
            
            
            
            System.out.println("Digite 5 para jogar novamente ");
            System.out.print("-> ");
            iniciar = sc.nextInt();
        }
        System.out.print("Obrigado por jogar Letrexto!");

        sc.close();

    }
}

            //palavraSorteada myPalavra = new palavraSorteada();
            //System.out.println(myPalavra.getaPalavra());