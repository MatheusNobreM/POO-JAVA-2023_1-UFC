
public class processamentoDoPalpite {
    //private String palpite;
    private palavraSorteada palavraDoDia;
    private String palavraTentada;
    
    
    processamentoDoPalpite() {
        
        palavraSorteada palavraDoDia = new palavraSorteada();
        
    }
    
    public String getPalavraTentada() {
        return palavraTentada;
    }
    public void setPalavraTentada(String palavraTentada) {
        this.palavraTentada = palavraTentada;
    }


    public String impressaoPalpite () {

        StringBuilder result = new StringBuilder();
        for (int i = 0; i < palavraTentada.length(); i++) {
            result.append(palavraTentada.charAt(i));
            if (i < palavraTentada.length() - 1) {
                result.append(" ");
            }
        }

        String finalResult = result.toString();

        return finalResult + "\n";
    }

    public String impressaoResposta () {



        return "";
    }




}
